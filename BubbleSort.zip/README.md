# Fundamental Algorithm

## Algorithm 기초 Swift
Xcode의 Playground로 작성되었습니다. Clone하여 Xcode에서 코드를 각 단계별로 print 해 보면 이해하기 쉽습니다.
* [거품 정렬(Bubble sort)](https://github.com/hyeonmin-yoo/Algorithm/tree/master/Algorithm/BubbleSort.playground)
* 선택 정렬(Selection sort)
* 삽입 정렬(Insertion sort)
* 셸 정렬(Shell sort)
* 합병 정렬(Merge sort)
* 퀵 정렬(Quick sort)
* 힙 정렬(Heap sort)

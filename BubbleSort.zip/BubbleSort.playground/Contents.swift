// 오름차순 정렬 (Ascending order)
var numbers = [1, 3, 9, 8, 7, 6, 2, 4, 5, 15, 13, 14, 11, 10, 12]
var temp = 0
var leftNumber = 0
var rightNumber = 0

for _ in 0..<numbers.count {
	for innerIndex in 0..<(numbers.count - 1) {
		leftNumber = numbers[innerIndex]
		rightNumber = numbers[innerIndex + 1]
		if leftNumber > rightNumber {
			temp = leftNumber
			numbers[innerIndex] = rightNumber
			numbers[innerIndex + 1] = temp
		}
	}
	print(numbers)
}
